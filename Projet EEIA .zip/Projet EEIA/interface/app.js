// ═══════════════════════════════════════════════════
// MODÈLE ML (RandomForest en JS, sans API Flask)
// Format model.json : MinMaxScaler + 6 features + 2 classes
// ═══════════════════════════════════════════════════
let _model = null; // sera chargé depuis model.json

async function loadModel() {
  if (_model) return _model;
  const res = await fetch('model.json');
  _model = await res.json();
  return _model;
}

function predictLocal(vals) {
  // Ordre des features : Age, SystolicBP, DiastolicBP, BS, BodyTemp, HeartRate
  const FEATURES = ['Age', 'SystolicBP', 'DiastolicBP', 'BS', 'BodyTemp', 'HeartRate'];
  const raw = FEATURES.map(f => vals[f]);

  // MinMaxScaler : scaled = (x - min) * scale   (scale_ = 1/(max-min) dans sklearn)
  const scaled = raw.map((v, i) => (v - _model.scaler.min[i]) * _model.scaler.scale[i]);

  // Parcours de chaque arbre (CART)
  const nClasses = _model.classes.length;
  const votes = new Array(nClasses).fill(0);

  for (const tree of _model.trees) {
    let node = 0;
    while (tree.children_left[node] !== -1) {
      node = scaled[tree.feature[node]] <= tree.threshold[node]
        ? tree.children_left[node]
        : tree.children_right[node];
    }
    // tree.value[node] est [[c0, c1, ...]]
    const leafCounts = tree.value[node][0];
    const total = leafCounts.reduce((a, b) => a + b, 0);
    for (let c = 0; c < nClasses; c++) votes[c] += leafCounts[c] / total;
  }

  // Normaliser les probabilités
  const sumV = votes.reduce((a, b) => a + b, 0);
  const proba = votes.map(v => v / sumV);

  // Classe prédite = argmax
  let bestIdx = 0;
  for (let i = 1; i < nClasses; i++) if (proba[i] > proba[bestIdx]) bestIdx = i;

  const prediction = _model.classes[bestIdx];

  // Construire prob_dict
  const probabilities = {};
  _model.classes.forEach((c, i) => { probabilities[c] = Math.round(proba[i] * 10000) / 10000; });

  return { risk: prediction, probabilities };
}

// ═══════════════════════════════════════════════════
// ÉTAT DE SESSION
// ═══════════════════════════════════════════════════
let history = [];
let lastResult = null;

// ═══════════════════════════════════════════════════
// ONGLETS
// ═══════════════════════════════════════════════════
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('tab-' + btn.dataset.tab).classList.add('active');
    if (btn.dataset.tab === 'dashboard') renderDashboard();
    if (btn.dataset.tab === 'historique') renderHistory();
  });
});

// ═══════════════════════════════════════════════════
// RÈGLES DE VALIDATION PAR CHAMP
// ═══════════════════════════════════════════════════
const rules = {
  Age:        { ok: v => v >= 10 && v <= 35,  warn: v => (v > 35 && v <= 45) || (v >= 0 && v < 10), label: 'Âge',             unit: 'ans',    fmt: v => v },
  SystolicBP: { ok: v => v >= 90 && v <= 120, warn: v => (v > 120 && v <= 140),                       label: 'Tension Syst.',  unit: 'mmHg',   fmt: v => v },
  DiastolicBP:{ ok: v => v >= 60 && v <= 80,  warn: v => (v > 80 && v <= 90),                         label: 'Tension Diast.', unit: 'mmHg',   fmt: v => v },
  BS:         { ok: v => v >= 3.9 && v <= 5.6,warn: v => (v > 5.6 && v <= 7.0),                       label: 'Glycémie',       unit: 'mmol/L', fmt: v => v.toFixed(1) },
  BodyTemp:   { ok: v => v >= 97 && v <= 99,  warn: v => (v > 99 && v <= 100.4),                      label: 'Température',    unit: '°F',     fmt: v => v.toFixed(1) },
  HeartRate:  { ok: v => v >= 70 && v <= 100, warn: v => (v > 100 && v <= 110) || (v >= 60 && v < 70),label: 'Fréq. Cardiaque',unit: 'bpm',    fmt: v => v }
};

function getFieldClass(id, v) {
  const r = rules[id];
  if (r.ok(v))   return 'ok';
  if (r.warn(v)) return 'warn';
  return 'danger';
}

function getFieldLabel(cls) {
  return cls === 'ok' ? 'Normal' : cls === 'warn' ? 'Attention' : 'Anormal';
}

// Coloration en temps réel
Object.keys(rules).forEach(id => {
  const input = document.getElementById(id);
  const st    = document.getElementById('st-' + id);
  if (!input) return;
  input.addEventListener('input', () => {
    const v = parseFloat(input.value);
    if (isNaN(v) || input.value === '') {
      input.className = '';
      st.className = 'field-status';
      return;
    }
    const cls = getFieldClass(id, v);
    input.className  = cls === 'ok' ? 'field-ok' : cls === 'warn' ? 'field-warn' : 'field-danger';
    st.className     = 'field-status ' + (cls === 'ok' ? 'normal' : cls === 'warn' ? 'warning' : 'danger');
    st.textContent   = getFieldLabel(cls);
  });
});

// Reset champs
document.getElementById('resetBtn').addEventListener('click', () => {
  Object.keys(rules).forEach(id => {
    const input = document.getElementById(id);
    const st    = document.getElementById('st-' + id);
    if (input) input.className = '';
    if (st)    st.className    = 'field-status';
  });
  document.getElementById('result').style.display = 'none';
});

// ═══════════════════════════════════════════════════
// FORMULAIRE + ANALYSE
// ═══════════════════════════════════════════════════
document.getElementById('riskForm').addEventListener('submit', async function(e) {
  e.preventDefault();

  const vals = {
    Age:         parseFloat(document.getElementById('Age').value),
    SystolicBP:  parseFloat(document.getElementById('SystolicBP').value),
    DiastolicBP: parseFloat(document.getElementById('DiastolicBP').value),
    BS:          parseFloat(document.getElementById('BS').value),
    BodyTemp:    parseFloat(document.getElementById('BodyTemp').value),
    HeartRate:   parseFloat(document.getElementById('HeartRate').value)
  };

  // — État de chargement —
  const submitBtn = this.querySelector('button[type="submit"]');
  const originalBtnHTML = submitBtn.innerHTML;
  submitBtn.disabled = true;
  submitBtn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="animation:spin .8s linear infinite"><path d="M21 12a9 9 0 1 1-6.22-8.56"/></svg> Analyse en cours…';

  const resultDiv = document.getElementById('result');
  const title     = document.getElementById('resultTitle');
  const msg       = document.getElementById('resultMsg');
  const pg        = document.getElementById('paramGrid');

  let risk;
  try {
    // — Prédiction locale (RandomForest en JS) —
    await loadModel();
    const data = predictLocal(vals);

    // Normaliser la classe (le modèle retourne "high risk" ou "low risk" en minuscules)
    const pred = data.risk.toLowerCase();
    risk = pred.includes('high') ? 'high' : 'low';

    // Probabilités (classes normalisées en minuscules par l'export notebook)
    const pHigh = Object.entries(data.probabilities)
      .filter(([k]) => k.toLowerCase().includes('high'))
      .reduce((s, [, v]) => s + v, 0);
    const pLow = Object.entries(data.probabilities)
      .filter(([k]) => k.toLowerCase().includes('low'))
      .reduce((s, [, v]) => s + v, 0);

    const probHigh = pHigh > 0 ? ` (${Math.round(pHigh * 100)}%)` : '';
    const probLow  = pLow  > 0 ? ` (${Math.round(pLow  * 100)}%)` : '';

    resultDiv.style.display = 'block';
    resultDiv.className = 'result-block ' + risk;
    title.textContent   = risk === 'high'
      ? `HIGH RISK — Risque Élevé${probHigh}`
      : `LOW RISK — Risque Faible${probLow}`;
    msg.textContent     = risk === 'high'
      ? 'Le modèle ML indique un risque élevé de mortalité maternelle. Une évaluation clinique urgente et une prise en charge immédiate sont recommandées.'
      : 'Le modèle ML indique que les paramètres vitaux sont dans les plages normales. Maintenir le suivi prénatal régulier selon le protocole en vigueur.';

  } catch (err) {
    resultDiv.style.display = 'block';
    resultDiv.className = 'result-block high';
    title.textContent   = 'Erreur de prédiction';
    msg.textContent     = `Impossible de charger ou d'exécuter le modèle. (${err.message})`;
    pg.innerHTML = '';
    submitBtn.disabled = false;
    submitBtn.innerHTML = originalBtnHTML;
    return;
  }

  // — Restaurer le bouton —
  submitBtn.disabled = false;
  submitBtn.innerHTML = originalBtnHTML;

  // Mini chips par paramètre
  pg.innerHTML = Object.keys(rules).map(id => {
    const r   = rules[id];
    const cls = getFieldClass(id, vals[id]);
    return `<div class="param-chip ${cls}">
      <div class="pc-label">${r.label}</div>
      <div class="pc-val">${r.fmt(vals[id])} ${r.unit}</div>
    </div>`;
  }).join('');

  resultDiv.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

  // Sauvegarder en historique
  const now   = new Date();
  const entry = { ...vals, risk, time: now, id: history.length + 1 };
  history.unshift(entry);
  lastResult = entry;
  document.getElementById('sessionCount').textContent = history.length;

  // Notifier le chatbot
  chatNotif.style.display = 'block';
});

// ═══════════════════════════════════════════════════
// RAPPORT (MODAL)
// ═══════════════════════════════════════════════════
const modalOverlay = document.getElementById('modalOverlay');

function openReport(entry) {
  if (!entry) return;
  document.getElementById('modalDate').textContent =
    'Analyse du ' + entry.time.toLocaleDateString('fr-FR') + ' à ' + entry.time.toLocaleTimeString('fr-FR', {hour:'2-digit',minute:'2-digit'});

  const paramsHTML = Object.keys(rules).map(id => {
    const r   = rules[id];
    const cls = getFieldClass(id, entry[id]);
    const lbl = getFieldLabel(cls);
    return `<div class="modal-param ${cls}">
      <div class="mp-name">${r.label}</div>
      <div class="mp-val">${r.fmt(entry[id])} ${r.unit}</div>
      <div class="mp-status">${lbl}</div>
    </div>`;
  }).join('');
  document.getElementById('modalParams').innerHTML = paramsHTML;

  const v = document.getElementById('modalVerdict');
  v.className = 'modal-verdict ' + entry.risk;
  v.innerHTML = entry.risk === 'high'
    ? '<h4>HIGH RISK — Risque Élevé</h4><p>Les paramètres vitaux dépassent les seuils normaux. Une évaluation clinique urgente et une prise en charge immédiate sont requises. Ne pas différer la consultation.</p>'
    : '<h4>LOW RISK — Risque Faible</h4><p>Les paramètres vitaux sont dans les plages normales pour une grossesse. Maintenir le suivi prénatal régulier et surveiller l\'évolution des constantes.</p>';

  const recos = entry.risk === 'high'
    ? ['Orientation immédiate vers un médecin spécialiste','Contrôle tensionnel et glycémique d\'urgence','Surveillance du rythme cardiaque fœtal','Envisager une hospitalisation si la situation se confirme']
    : ['Poursuivre les consultations prénatales régulières','Contrôle tensionnel à chaque visite','Dépistage du diabète gestationnel entre 24 et 28 SA','Maintenir une activité physique légère et adaptée'];

  document.getElementById('modalReco').innerHTML = recos.map(r =>
    `<li class="tip-item"><div class="tip-icon">✔</div><div>${r}</div></li>`
  ).join('');

  modalOverlay.classList.add('open');
}

document.getElementById('btnReport').addEventListener('click', () => openReport(lastResult));
document.getElementById('modalClose').addEventListener('click', () => modalOverlay.classList.remove('open'));
document.getElementById('modalCloseBtn').addEventListener('click', () => modalOverlay.classList.remove('open'));
document.getElementById('modalOverlay').addEventListener('click', e => { if (e.target === modalOverlay) modalOverlay.classList.remove('open'); });
document.getElementById('modalPrint').addEventListener('click', () => window.print());
document.getElementById('btnPrint').addEventListener('click', () => { openReport(lastResult); setTimeout(() => window.print(), 300); });

// ═══════════════════════════════════════════════════
// HISTORIQUE
// ═══════════════════════════════════════════════════
function renderHistory() {
  const count  = document.getElementById('historyCount');
  const empty  = document.getElementById('historyEmpty');
  const table  = document.getElementById('historyTable');
  const body   = document.getElementById('historyBody');
  count.textContent = history.length + ' analyse(s)';
  if (history.length === 0) { empty.style.display='block'; table.style.display='none'; return; }
  empty.style.display = 'none'; table.style.display = 'table';
  body.innerHTML = history.map(e => `
    <tr>
      <td>${e.id}</td>
      <td>${e.time.toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'})}</td>
      <td>${e.Age}</td>
      <td>${e.SystolicBP}</td>
      <td>${e.DiastolicBP}</td>
      <td>${e.BS.toFixed(1)}</td>
      <td>${e.BodyTemp.toFixed(1)}</td>
      <td>${e.HeartRate}</td>
      <td><span class="badge-risk ${e.risk}">${e.risk === 'high' ? 'HIGH RISK' : 'LOW RISK'}</span></td>
    </tr>`).join('');
}

document.getElementById('clearHistory').addEventListener('click', () => {
  if (confirm('Effacer tout l\'historique de cette session ?')) {
    history = [];
    lastResult = null;
    document.getElementById('sessionCount').textContent = '0';
    renderHistory();
  }
});

// ═══════════════════════════════════════════════════
// DASHBOARD
// ═══════════════════════════════════════════════════
function renderDashboard() {
  const total = history.length;
  const high  = history.filter(e => e.risk === 'high').length;
  const low   = total - high;

  document.getElementById('kpiTotal').textContent = total;
  document.getElementById('kpiHigh').textContent  = high;
  document.getElementById('kpiLow').textContent   = low;
  document.getElementById('kpiHighPct').textContent = total > 0 ? Math.round(high/total*100) + '% des analyses' : '—';
  document.getElementById('kpiLowPct').textContent  = total > 0 ? Math.round(low/total*100)  + '% des analyses' : '—';

  // Légende donut
  document.getElementById('legendLow').textContent  = low;
  document.getElementById('legendHigh').textContent = high;

  // Donut SVG
  const dLow  = document.getElementById('donutLow');
  const dHigh = document.getElementById('donutHigh');
  if (total > 0) {
    const pLow  = Math.round(low/total*100);
    const pHigh = 100 - pLow;
    dLow.setAttribute('stroke-dasharray',  pLow  + ' ' + pHigh);
    dLow.setAttribute('stroke-dashoffset', '25');
    dHigh.setAttribute('stroke-dasharray', pHigh + ' ' + pLow);
    dHigh.setAttribute('stroke-dashoffset', (25 - pLow).toString());
    dHigh.style.opacity = '1';
  }

  // Bar chart anomalies
  if (total === 0) {
    document.getElementById('barChart').innerHTML = '<p style="font-size:12px;color:#5d6d7e;text-align:center;padding:20px 0">Aucune donnée disponible.</p>';
    return;
  }

  const anomCounts = { SystolicBP:0, DiastolicBP:0, BS:0, BodyTemp:0, HeartRate:0, Age:0 };
  history.forEach(e => {
    Object.keys(anomCounts).forEach(k => {
      if (!rules[k].ok(e[k])) anomCounts[k]++;
    });
  });

  const barLabels = { SystolicBP:'Tens. Syst.', DiastolicBP:'Tens. Diast.', BS:'Glycémie', BodyTemp:'Température', HeartRate:'Fréq. Cardiaque', Age:'Âge' };
  const maxVal = Math.max(...Object.values(anomCounts), 1);
  document.getElementById('barChart').innerHTML = Object.keys(anomCounts).map(k => {
    const pct = Math.round(anomCounts[k] / maxVal * 100);
    const cls = anomCounts[k] === 0 ? 'ok' : anomCounts[k] < total/2 ? 'warn' : 'danger';
    return `<div class="bar-row">
      <div class="bar-label">${barLabels[k]}</div>
      <div class="bar-track"><div class="bar-fill ${cls}" style="width:${pct}%"></div></div>
      <div class="bar-val">${anomCounts[k]}</div>
    </div>`;
  }).join('');
}

// ═══════════════════════════════════════════════════
// CHATBOT
// ═══════════════════════════════════════════════════
const chatFab      = document.getElementById('chatFab');
const chatWindow   = document.getElementById('chatWindow');
const chatClose    = document.getElementById('chatClose');
const chatInput    = document.getElementById('chatInput');
const chatSendBtn  = document.getElementById('chatSendBtn');
const chatMessages = document.getElementById('chatMessages');
const chatNotif    = document.getElementById('chatNotif');

chatFab.addEventListener('click', () => { chatWindow.classList.toggle('open'); chatNotif.style.display='none'; });
chatClose.addEventListener('click', () => chatWindow.classList.remove('open'));

function addMessage(text, sender) {
  const div = document.createElement('div');
  div.className = 'msg ' + sender;
  div.innerHTML = sender === 'bot'
    ? `<div class="msg-av">🩺</div><div class="msg-bubble">${text}</div>`
    : `<div class="msg-bubble">${text}</div>`;
  chatMessages.appendChild(div);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

function showTyping() {
  const div = document.createElement('div');
  div.className = 'msg bot typing'; div.id = 'typingIndicator';
  div.innerHTML = `<div class="msg-av">🩺</div><div class="msg-bubble"><span class="dot"></span><span class="dot"></span><span class="dot"></span></div>`;
  chatMessages.appendChild(div);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}
function removeTyping() { const t = document.getElementById('typingIndicator'); if (t) t.remove(); }

function botReply(question) {
  showTyping();
  setTimeout(() => {
    removeTyping();
    const q = question.toLowerCase();
    let answer = '';

    if (q.includes('historique') || q.includes('analyses') || q.includes('session')) {
      const total = history.length;
      if (total === 0) {
        answer = 'Aucune analyse n\'a été effectuée dans cette session. Allez dans l\'onglet <strong>Analyse</strong> pour commencer.';
      } else {
        const high = history.filter(e => e.risk === 'high').length;
        answer = `Cette session compte <strong>${total} analyse(s)</strong> : <strong style="color:#1e8449">${total-high} Low Risk</strong> et <strong style="color:#c0392b">${high} High Risk</strong>. Consultez l'onglet <strong>Historique</strong> pour le détail.`;
      }
    } else if (q.includes('high risk') || q.includes('risque élevé') || q.includes('risque eleve')) {
      answer = '<strong>High Risk</strong> indique que les paramètres vitaux dépassent les seuils normaux. Une évaluation clinique urgente et une prise en charge immédiate sont requises.';
    } else if (q.includes('low risk') || q.includes('risque faible')) {
      answer = '<strong>Low Risk</strong> indique que les paramètres sont dans les plages normales. Le suivi prénatal régulier doit être maintenu.';
    } else if (q.includes('glycémie') || q.includes('glycemie') || q.includes('bs') || q.includes('sucre')) {
      answer = 'La <strong>glycémie</strong> normale à jeun pendant la grossesse est entre <strong>3.9 et 5.6 mmol/L</strong>. Au-delà de 7.0, un diabète gestationnel doit être investigué.';
    } else if (q.includes('tension') || q.includes('systolique') || q.includes('diastolique') || q.includes('pression')) {
      answer = 'Tension normale pendant la grossesse :<br>• <strong>Systolique</strong> : 90 – 120 mmHg<br>• <strong>Diastolique</strong> : 60 – 80 mmHg<br>Une tension ≥ 140/90 évoque une <strong>prééclampsie</strong> — consultation urgente.';
    } else if (q.includes('prééclampsie') || q.includes('preeclampsie') || q.includes('éclampsie')) {
      answer = 'La <strong>prééclampsie</strong> est une HTA (≥ 140/90) associée à une protéinurie après 20 SA. Signes d\'alarme : céphalées, troubles visuels, épigastralgies. Urgence obstétricale.';
    } else if (q.includes('température') || q.includes('temperature') || q.includes('fièvre')) {
      answer = 'La température normale est <strong>97 – 99°F (36.1 – 37.2°C)</strong>. Une fièvre ≥ 100.4°F (38°C) pendant la grossesse nécessite une consultation médicale rapide.';
    } else if (q.includes('cardiaque') || q.includes('bpm') || q.includes('pouls') || q.includes('fréquence')) {
      answer = 'La fréquence cardiaque normale pendant la grossesse est entre <strong>70 et 100 bpm</strong>. Une légère augmentation est physiologiquement normale.';
    } else if (q.includes('diabète') || q.includes('diabete') || q.includes('gestationnel')) {
      answer = 'Le <strong>diabète gestationnel</strong> se dépiste entre 24 et 28 SA (HGPO). Il augmente les risques obstétricaux. Prise en charge : régime, surveillance glycémique, insuline si nécessaire.';
    } else if (q.includes('âge') || q.includes('age')) {
      answer = 'L\'<strong>âge maternel avancé</strong> (≥ 35 ans) est un facteur de risque : HTA, diabète gestationnel, anomalies chromosomiques, complications obstétricales.';
    } else if (q.includes('rapport') || q.includes('imprimer') || q.includes('exporter')) {
      answer = 'Après une analyse, cliquez sur le bouton <strong>"Rapport"</strong> ou <strong>"Imprimer"</strong> visible dans le résultat pour générer et imprimer le rapport complet.';
    } else if (q.includes('réduire') || q.includes('reduire') || q.includes('prévenir') || q.includes('prevenir')) {
      answer = 'Pour réduire le risque maternel :<br>• Consultations prénatales régulières<br>• Surveillance TA et glycémie<br>• Alimentation équilibrée, hydratation<br>• Signalement de tout symptôme inhabituel';
    } else if (q.includes('urgence') || q.includes('danger')) {
      answer = 'En cas d\'urgence obstétricale : activer le protocole d\'urgence de l\'établissement, orienter vers la salle de travail ou le bloc obstétrical selon la situation.';
    } else if (q.includes('dashboard') || q.includes('statistiques') || q.includes('stats')) {
      answer = 'L\'onglet <strong>Dashboard</strong> affiche les statistiques de votre session : nombre total d\'analyses, répartition Low/High Risk, et les paramètres les plus souvent anormaux.';
    } else if (q.includes('bonjour') || q.includes('salut') || q.includes('bonsoir')) {
      answer = 'Bonjour. Comment puis-je vous aider ?';
    } else if (q.includes('merci')) {
      answer = 'De rien. N\'hésitez pas si vous avez d\'autres questions.';
    } else if (q.includes('modèle') || q.includes('modele') || q.includes('ia') || q.includes('algorithme')) {
      answer = 'Ce système utilise un modèle de <strong>Machine Learning supervisé</strong> entraîné sur des données cliniques maternelles pour classifier le risque à partir de 6 paramètres vitaux.';
    } else {
      answer = 'Je n\'ai pas trouvé de réponse précise. Essayez :<br>• <em>High Risk ?</em><br>• <em>Tension normale grossesse ?</em><br>• <em>Voir mon historique</em><br>• <em>Comment imprimer un rapport ?</em>';
    }
    addMessage(answer, 'bot');
  }, 800);
}

function sendMessage() {
  const text = chatInput.value.trim();
  if (!text) return;
  addMessage(text, 'user'); chatInput.value = '';
  botReply(text);
}

function quickAsk(text) {
  chatWindow.classList.add('open'); chatNotif.style.display = 'none';
  addMessage(text, 'user'); botReply(text);
}

chatSendBtn.addEventListener('click', sendMessage);
chatInput.addEventListener('keydown', e => { if (e.key === 'Enter') sendMessage(); });
