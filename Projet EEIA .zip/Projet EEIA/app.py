# app.py - Serveur Flask pour MediRisk
# Lancement : python app.py
# Puis ouvrir : http://127.0.0.1:5000

from flask import Flask, send_from_directory
import os

BASE_DIR  = os.path.dirname(os.path.abspath(__file__))
INTERFACE = os.path.join(BASE_DIR, "interface")

app = Flask(__name__)


@app.route("/")
def index():
    return send_from_directory(INTERFACE, "index.html")


@app.route("/<path:filename>")
def static_files(filename):
    return send_from_directory(INTERFACE, filename)


if __name__ == "__main__":
    print("")
    print("  MediRisk pret !")
    print("  Ouvre : http://127.0.0.1:5000")
    print("")
    app.run(debug=True, host="127.0.0.1", port=5000)
